#pragma once
#include <Arduino.h>
#include "GluNIR_Config.h"

struct GluNIRWindow {
    float redMean;
    float irMean;
    float hrMean;
    uint32_t n;
};

struct GluNIRStats {
    float sumRed = 0, sumIr = 0, sumHr = 0;
    uint32_t n = 0;
};

static inline void glunirStatsAdd(GluNIRStats &s, float red, float ir, float hr) {
    s.sumRed += red; s.sumIr += ir;
    if (hr > 0) s.sumHr += hr;
    s.n++;
}

static inline GluNIRWindow glunirFinishWindow(const GluNIRStats &s) {
    GluNIRWindow w{};
    if (s.n == 0) return w;
    w.redMean = s.sumRed / s.n;
    w.irMean = s.sumIr / s.n;
    w.hrMean = s.sumHr / s.n;
    w.n = s.n;
    return w;
}

// Explicit adapter from raw MAX30100 RED to the model's I660 feature domain.
// Replace GLUNIR_I660_OFFSET/SCALE after paired hardware calibration.
static inline float glunirI660Feature(const GluNIRWindow &w) {
    return GLUNIR_I660_OFFSET + GLUNIR_I660_SCALE * w.redMean;
}
