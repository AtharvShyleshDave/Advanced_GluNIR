GluNIR Stage 6 Final TinyML Package
====================================

This folder is intended to be opened directly in Arduino IDE.

Files
-----
GluNIR_Stage6.ino       Main firmware.
GluNIR_Model.h          Exact frozen Stage 4F scaler + MLP weights.
GluNIR_MAX30100.h       Minimal raw MAX30100 driver + HR estimator.
GluNIR_BPW34.h          BPW34 + external 940 nm acquisition.
GluNIR_Signal.h         Measurement-window accumulation.
GluNIR_Config.h         Pin and timing configuration.

Stage 4F source
---------------
The uploaded Stage 4F script trains:
  Features: I660, I940
  Median imputation
  StandardScaler
  MLP 2 -> 16 -> 8 -> 1
  ReLU
  Adam
  learning_rate_init = 0.0003
  alpha = 0.0001
  random_state = 42
  max_iter = 5000
  early_stopping = False

The exact fitted parameters were reproduced from:
  04_train.csv + 05_validation.csv
using the uploaded Stage 4F training procedure.

Stage 4F reported:
  MAE  = 19.282423 mg/dL
  RMSE = 21.136196 mg/dL
  R2   = 0.150010
  bias = +0.643786 mg/dL

Pins
----
GPIO 8  = I2C SDA
GPIO 9  = I2C SCL
GPIO 0  = MCP6002 / BPW34 TIA ADC output
GPIO 4  = external 940 nm LED MOSFET gate

CRITICAL PHYSICAL-CALIBRATION NOTE
-----------------------------------
The embedded neural network is exact, but the public STUBA I660/I940
features are dataset-domain quantities. ESP32 ADC counts and MAX30100
raw counts are not automatically identical to those feature quantities.

Therefore GluNIR_Config.h exposes:
  GLUNIR_I660_OFFSET
  GLUNIR_I660_SCALE
  GLUNIR_I940_OFFSET
  GLUNIR_I940_SCALE

They are currently identity values. This lets the firmware run end-to-end,
but it does NOT claim that the physical sensor has already been calibrated
to the STUBA feature domain.

For a scientifically valid hardware result, collect paired hardware
measurements and determine these feature mappings before treating the
returned glucose as a validated device measurement.

HR-glucose correlation
----------------------
The firmware accumulates Pearson correlation between the current HR and
the model's predicted glucose over multiple completed windows. It is not
computed from a single measurement.

This correlation is descriptive and does not imply causality or clinical
validity.
