#pragma once
#include <Arduino.h>

// GluNIR Stage 6 hardware configuration
#define GLUNIR_SDA_PIN       8
#define GLUNIR_SCL_PIN       9
#define GLUNIR_BPW_ADC_PIN   0
#define GLUNIR_LED_940_PIN   4

#define GLUNIR_ADC_BITS      12
#define GLUNIR_ADC_ATTEN     ADC_11db

// Measurement window
#define GLUNIR_WINDOW_MS     10000UL
#define GLUNIR_SAMPLE_MS     20UL
#define GLUNIR_LED_SETTLE_MS 10UL
#define GLUNIR_BPW_AVG       8

// Basic quality limits
#define GLUNIR_ADC_SAT       4000
#define GLUNIR_MIN_NET       20

// BPW34 feature calibration.
// The public STUBA model's I940 feature is in the calibrated dataset feature
// domain, not ESP32 ADC counts. These two values are intentionally explicit
// and must be replaced by physical-device calibration once paired calibration
// data are collected.
#define GLUNIR_I940_OFFSET   0.0f
#define GLUNIR_I940_SCALE    1.0f

// MAX30100 raw RED conversion.
// The same caveat applies: this is the hardware-to-dataset feature adapter,
// not a learned glucose calibration.
#define GLUNIR_I660_OFFSET   0.0f
#define GLUNIR_I660_SCALE    1.0f
