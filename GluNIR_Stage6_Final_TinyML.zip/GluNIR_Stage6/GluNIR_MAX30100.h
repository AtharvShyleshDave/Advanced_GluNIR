#pragma once
#include <Arduino.h>
#include <Wire.h>
#include "GluNIR_Config.h"

// Minimal MAX30100 raw FIFO reader.
// This avoids the PulseOximeter abstraction because Stage 4F needs the RED
// optical feature, not just HR/SpO2.

namespace GluNIRMAX {

static constexpr uint8_t ADDR = 0x57;
static constexpr uint8_t REG_INT_STATUS = 0x00;
static constexpr uint8_t REG_FIFO_WR_PTR = 0x02;
static constexpr uint8_t REG_OVF_COUNTER = 0x03;
static constexpr uint8_t REG_FIFO_RD_PTR = 0x04;
static constexpr uint8_t REG_FIFO_DATA = 0x05;
static constexpr uint8_t REG_MODE_CONFIG = 0x06;
static constexpr uint8_t REG_SPO2_CONFIG = 0x07;
static constexpr uint8_t REG_LED_CONFIG = 0x09;
static constexpr uint8_t REG_TEMP_INT = 0x16;
static constexpr uint8_t REG_TEMP_FRAC = 0x17;

static inline bool writeReg(uint8_t reg, uint8_t value) {
    Wire.beginTransmission(ADDR);
    Wire.write(reg); Wire.write(value);
    return Wire.endTransmission() == 0;
}

static inline uint8_t readReg(uint8_t reg) {
    Wire.beginTransmission(ADDR);
    Wire.write(reg);
    if (Wire.endTransmission(false) != 0) return 0;
    Wire.requestFrom(ADDR, (uint8_t)1);
    return Wire.available() ? Wire.read() : 0;
}

static inline bool begin() {
    Wire.begin(GLUNIR_SDA_PIN, GLUNIR_SCL_PIN);
    Wire.setClock(400000);
    Wire.beginTransmission(ADDR);
    if (Wire.endTransmission() != 0) return false;

    writeReg(REG_MODE_CONFIG, 0x40); // reset
    delay(10);

    // SpO2 mode, ~100 Hz, 1600 us pulse width.
    writeReg(REG_MODE_CONFIG, 0x03);
    writeReg(REG_SPO2_CONFIG, 0x47);
    // RED + IR current ~24mA each.
    writeReg(REG_LED_CONFIG, 0x77);

    writeReg(REG_FIFO_WR_PTR, 0x00);
    writeReg(REG_OVF_COUNTER, 0x00);
    writeReg(REG_FIFO_RD_PTR, 0x00);
    return true;
}

static inline bool readSample(uint16_t &ir, uint16_t &red) {
    Wire.beginTransmission(ADDR);
    Wire.write(REG_FIFO_DATA);
    if (Wire.endTransmission(false) != 0) return false;
    if (Wire.requestFrom(ADDR, (uint8_t)4) != 4) return false;

    // MAX30100 FIFO order: IR MSB/LSB, RED MSB/LSB.
    ir  = ((uint16_t)Wire.read() << 8) | Wire.read();
    red = ((uint16_t)Wire.read() << 8) | Wire.read();
    return true;
}

static inline uint8_t fifoAvailable() {
    uint8_t wr = readReg(REG_FIFO_WR_PTR);
    uint8_t rd = readReg(REG_FIFO_RD_PTR);
    return (wr - rd) & 0x0F;
}

struct HRTracker {
    float bpm;
    uint32_t lastBeat;
    float prev;
    float prev2;
    float dc;
    float amp;
    bool initialized;
};

static inline void resetHR(HRTracker &h) {
    h = {};
    h.dc = 0;
    h.amp = 1;
}

static inline void updateHR(HRTracker &h, float ir, uint32_t now) {
    // Lightweight AC/DC pulse detector for deployment.
    if (!h.initialized) {
        h.dc = ir; h.prev2 = ir; h.prev = ir; h.initialized = true; return;
    }
    h.dc = 0.99f*h.dc + 0.01f*ir;
    float ac = ir - h.dc;
    h.amp = 0.995f*h.amp + 0.005f*fabsf(ac);
    float threshold = fmaxf(0.15f*h.amp, 20.0f);

    // local maximum crossing
    if (h.prev > h.prev2 && h.prev > ac && h.prev > threshold) {
        if (h.lastBeat != 0) {
            uint32_t dt = now - h.lastBeat;
            if (dt >= 300 && dt <= 2000) {
                float candidate = 60000.0f / dt;
                h.bpm = (h.bpm == 0) ? candidate : (0.75f*h.bpm + 0.25f*candidate);
            }
        }
        h.lastBeat = now;
    }
    h.prev2 = h.prev;
    h.prev = ac;
}

}
