#pragma once
#include <Arduino.h>
#include "GluNIR_Config.h"

struct BPWReading {
    float off1;
    float on;
    float off2;
    float net;
    bool saturated;
    bool ambientStable;
};

static inline uint16_t glunirReadBPWCounts() {
    uint32_t sum = 0;
    for (int i=0; i<GLUNIR_BPW_AVG; ++i) {
        sum += analogRead(GLUNIR_BPW_ADC_PIN);
        delayMicroseconds(250);
    }
    return (uint16_t)(sum / GLUNIR_BPW_AVG);
}

static inline BPWReading glunirReadBPW() {
    BPWReading r{};
    digitalWrite(GLUNIR_LED_940_PIN, LOW);
    delay(GLUNIR_LED_SETTLE_MS);
    r.off1 = glunirReadBPWCounts();

    digitalWrite(GLUNIR_LED_940_PIN, HIGH);
    delay(GLUNIR_LED_SETTLE_MS);
    r.on = glunirReadBPWCounts();

    digitalWrite(GLUNIR_LED_940_PIN, LOW);
    delay(GLUNIR_LED_SETTLE_MS);
    r.off2 = glunirReadBPWCounts();

    r.net = r.on - 0.5f * (r.off1 + r.off2);
    r.saturated = (r.off1 >= GLUNIR_ADC_SAT || r.on >= GLUNIR_ADC_SAT || r.off2 >= GLUNIR_ADC_SAT);
    r.ambientStable = fabsf(r.off1 - r.off2) <= 100.0f;
    return r;
}

static inline float glunirI940Feature(const BPWReading& r) {
    // Feature adapter. See README: physical calibration is required to make
    // ADC counts identical to the STUBA I940 feature domain.
    return GLUNIR_I940_OFFSET + GLUNIR_I940_SCALE * r.net;
}
