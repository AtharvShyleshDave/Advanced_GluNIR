#include <Arduino.h>
#include <Wire.h>
#include "GluNIR_Config.h"
#include "GluNIR_Model.h"
#include "GluNIR_MAX30100.h"
#include "GluNIR_BPW34.h"
#include "GluNIR_Signal.h"

// ============================================================
// GluNIR Stage 6
// SINGLE-SKETCH TinyML DEPLOYMENT
//
// Final Stage 4F model:
//   [I660, I940] -> StandardScaler -> 16 -> 8 -> 1
//
// The ESP32 returns:
//   - heart rate
//   - estimated glucose
//   - accumulated Pearson r between HR and predicted glucose
//
// IMPORTANT:
// The Stage 4F neural-network weights/scaler are frozen and embedded in
// GluNIR_Model.h. The physical sensor-to-dataset feature adapter is NOT a
// learned calibration. It must be calibrated against the real hardware.
// ============================================================

GluNIRMAX::HRTracker hrTracker;
GluNIRStats stats;

double sumHR = 0, sumG = 0, sumHR2 = 0, sumG2 = 0, sumHRG = 0;
uint32_t corrN = 0;

static void updateCorrelation(float hr, float glucose) {
    if (hr <= 0 || !isfinite(hr) || !isfinite(glucose)) return;
    sumHR += hr; sumG += glucose;
    sumHR2 += (double)hr*hr;
    sumG2 += (double)glucose*glucose;
    sumHRG += (double)hr*glucose;
    corrN++;

    if (corrN >= 2) {
        double num = corrN*sumHRG - sumHR*sumG;
        double denA = corrN*sumHR2 - sumHR*sumHR;
        double denB = corrN*sumG2 - sumG*sumG;
        double den = sqrt(fmax(denA,0.0)*fmax(denB,0.0));
        double r = (den > 1e-9) ? num/den : 0.0;
        Serial.printf("HR-Glucose Pearson r: %.4f (N=%lu)\n", r, (unsigned long)corrN);
    }
}

static void drainMAX() {
    while (GluNIRMAX::fifoAvailable() > 0) {
        uint16_t ir, red;
        if (!GluNIRMAX::readSample(ir, red)) break;
        uint32_t now = millis();
        GluNIRMAX::updateHR(hrTracker, (float)ir, now);
        glunirStatsAdd(stats, (float)red, (float)ir, hrTracker.bpm);
    }
}

void setup() {
    Serial.begin(115200);
    delay(1500);

    pinMode(GLUNIR_LED_940_PIN, OUTPUT);
    digitalWrite(GLUNIR_LED_940_PIN, LOW);
    pinMode(GLUNIR_BPW_ADC_PIN, INPUT);
    analogReadResolution(GLUNIR_ADC_BITS);
    analogSetPinAttenuation(GLUNIR_BPW_ADC_PIN, GLUNIR_ADC_ATTEN);

    Serial.println();
    Serial.println("==============================================");
    Serial.println(" GLUNIR STAGE 6 - TINYML GLUCOSE ESTIMATOR");
    Serial.println("==============================================");
    Serial.println("Model: Stage 4F  [I660, I940] -> 16 -> 8 -> 1");
    Serial.println("Hardware: ESP32-C3 + MAX30100 + BPW34 + 940nm LED");

    if (!GluNIRMAX::begin()) {
        Serial.println("ERROR: MAX30100 not detected.");
        while (true) delay(1000);
    }

    GluNIRMAX::resetHR(hrTracker);
    Serial.println("MAX30100 OK. Place finger and hold still.");
    Serial.println("Collecting 10-second measurement windows...");
}

void loop() {
    static uint32_t windowStart = millis();
    static uint32_t lastBp = 0;

    drainMAX();

    // Keep the external 940 nm measurement paced separately.
    if (millis() - lastBp >= 200) {
        lastBp = millis();
        BPWReading b = glunirReadBPW();
        // Store BPW net in a temporary static accumulator.
        static double bpwSum = 0;
        static uint32_t bpwN = 0;
        if (!b.saturated && b.ambientStable) {
            bpwSum += b.net;
            bpwN++;
        }

        if (millis() - windowStart >= GLUNIR_WINDOW_MS) {
            GluNIRWindow w = glunirFinishWindow(stats);

            float i660 = glunirI660Feature(w);
            float i940 = (bpwN > 0)
                ? (GLUNIR_I940_OFFSET + GLUNIR_I940_SCALE * (float)(bpwSum / bpwN))
                : NAN;

            float glucose = GluNIRModel::predict(i660, i940);

            Serial.println();
            Serial.println("------------- GLUNIR RESULT ----------------");
            Serial.printf("Samples             : %lu\n", (unsigned long)w.n);
            Serial.printf("I660 feature        : %.6f\n", i660);
            Serial.printf("I940 feature        : %.6f\n", i940);
            Serial.printf("Heart Rate          : %.1f BPM\n", hrTracker.bpm);
            Serial.printf("Estimated Glucose   : %.1f mg/dL\n", glucose);

            updateCorrelation(hrTracker.bpm, glucose);

            Serial.println("---------------------------------------------");
            Serial.println("Hold still for next window.");

            stats = {};
            bpwSum = 0;
            bpwN = 0;
            windowStart = millis();
        }
    }

    delay(2);
}
